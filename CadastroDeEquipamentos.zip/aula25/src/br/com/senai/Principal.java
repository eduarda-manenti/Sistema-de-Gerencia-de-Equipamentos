package br.com.senai;

import br.com.senai.view.ViewConsultaDeEquipamento;
import br.com.senai.view.ViewPrincipal;

public class Principal {

	public static void main(String[] args) {
		new  ViewPrincipal().setVisible(true);
	}

}
