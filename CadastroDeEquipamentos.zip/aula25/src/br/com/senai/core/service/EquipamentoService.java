package br.com.senai.core.service;

import java.util.List;

import br.com.senai.core.dao.DaoEquipamento;
import br.com.senai.core.dao.FactoryDao;
import br.com.senai.core.domain.Equipamento;
import br.com.senai.core.domain.Status;

public class EquipamentoService {
	
	private DaoEquipamento dao;
	
	public EquipamentoService() {
		this.dao = FactoryDao.getInstance().getDaoEquipamento();
	}
	
	
	public void salvar(Equipamento equipamento) {
		this.validar(equipamento);
		boolean isPersistido = equipamento.getId() > 0;
		if (isPersistido) {
			this.dao.alterar(equipamento);
		} else {
			this.dao.inserir(equipamento);
		}
	}
	
	private void validar(Equipamento equipamento) {
		if (equipamento != null) {
			boolean isDescricaoInvalida = equipamento.getDescricaoCurta() == null
					 || equipamento.getDescricaoCurta().isBlank()
					 || equipamento.getDescricaoCurta().length() < 3
					 || equipamento.getDescricaoCurta().length() > 150;
			
			if (isDescricaoInvalida) {
				throw new IllegalArgumentException("A descri��o curta � obrigat�ria e deve possuir entre 3 a 150 caracteres.");
			} 
			
			boolean isGarantiaInvalida = equipamento.getGarantia() < 1;
			if (isGarantiaInvalida) {
				throw new IllegalArgumentException("A garantia n�o pode ser um valor menor que zero.");
			}
			
			boolean isStatusInvalido = equipamento.getStatus() == null;
			if (isStatusInvalido) {
				throw new NullPointerException("O status � obrigat�rio.");
			}
			
			boolean isPersistido = equipamento.getId() > 0;
			if (isPersistido) {
				Equipamento equipamentoSalvo = dao.buscarPor(equipamento.getId());
				boolean isAlteracaoInvalida = equipamento.getStatus() != Status.E
						&& equipamentoSalvo.getStatus() == Status.R;
				if (isAlteracaoInvalida) {
					throw new IllegalArgumentException("O Equipamento j� foi entregue,"
							+ " n�o permitidno a altera��o do status dele.");
				}		
			}
					 } else {
			throw new NullPointerException("O Equipamento n�o pode ser nulo.");
		}
	}
	
	public void remover(int idDoEquipamento) {
		if (idDoEquipamento > 0) {
			this.dao.excluirPor(idDoEquipamento);
		} else {
			throw new IllegalArgumentException("O id para remo��o do equipamento"
					+ " deve ser maior que zero.");
		}
	}
	
	public List<Equipamento> listarPor(String descricao) {
		if (descricao != null && !descricao.isBlank()) {
			String filtro = descricao + "%";
			return dao.listarPor(filtro);
		} else {
			throw new IllegalArgumentException("A DESCRI��O � OBRIGAT�RIA!");
		}
	}

}
