package br.com.senai.core.domain;

public enum Status {
	R,
	E

}
